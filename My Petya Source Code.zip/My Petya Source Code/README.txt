2021 note:
This is my OG reverse of the leaked petya builder kit, sorry if formatting is fucked up but deal with it.
You can find the leaked copy on the root of this project.
- thanks to VXUG for posting it too! please follow them on twitter, https://twitter.com/vxunderground

===============================================================
UPDATE June 2019 RELEASE 1.1:

Fixed and cleaned the shotty decompile from October 25th 2018.

UPDATE July 2019 RELEASE 1.2:

Decompiled Mischa bin. Extracted MBR is included.

UPDATE April 2020 RELEASE 1.3:

Updated decompiled builder code to be more organised.

How to compile:

   To compile the client (the mischa dropper) you need Dev-C++ 5.11
   The download should be on sourceforge. Once it is installed, open
   the "client.dev" project and click the grey square window button.
   That should rebuild the whole source tree.

   To compile the builder, Have visual studio 2010 installed, and open
   up the sln file and build the soulution or the builder. This compiles
   with no warning in visual studio 2010, I have no idea about any later
   versions. That is why the original binary is included.

   If you want to use your custom compiled client, please find the "miha.bin"
   file in the builders "Resources" directory and replace it with the "miha.bin"
   Dev-C++ spit out, and recompile the builder. It >>SHOULD<< work.
